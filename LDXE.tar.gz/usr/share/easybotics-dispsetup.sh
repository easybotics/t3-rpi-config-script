#!/bin/sh
export DISPLAY=:0
xrandr --newmode "1280x800_60.00"   83.50  1280 1352 1480 1680  800 803 809 831 -hsync +vsync
xrandr --addmode HDMI-1 1280x800_60.00
xrandr --addmode HDMI-2 1280x800_60.00
xrandr --output HDMI-1  --mode 1280x800_60.00 --pos 0x0 
xrandr --output HDMI-2  --mode 1280x800_60.00 --pos 0x0 
