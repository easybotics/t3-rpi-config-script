cd /home/pi/.piwiz/
sudo ./piwiz
