cd /home/pi/.piwiz/
sudo raspi-config nonint do_expand_rootfs
sudo ./piwiz
