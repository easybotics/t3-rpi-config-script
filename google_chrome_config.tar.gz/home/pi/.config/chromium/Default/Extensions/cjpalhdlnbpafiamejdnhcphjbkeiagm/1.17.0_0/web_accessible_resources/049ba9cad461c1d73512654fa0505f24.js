(function() {
	var noopfn = function(){};
	window.pSUPERFLY = {
		activity: noopfn,
		virtualPage: noopfn
	};
})();
